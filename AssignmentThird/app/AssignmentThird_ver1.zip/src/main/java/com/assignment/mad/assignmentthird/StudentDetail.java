package com.assignment.mad.assignmentthird;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class StudentDetail extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_student_detail);
    }
}
