package com.assignment.mad.assignmentthird;

import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.io.File;

public class StudentDetail extends AppCompatActivity {

    SQLiteDatabase contactsDB = null;

    EditText st_name,st_reg,st_degree,st_department,st_phone,st_email;

    Button btnView,btnSave;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_student_detail);

        st_name = (EditText) findViewById(R.id.editTextName_st);
        st_reg = (EditText) findViewById(R.id.editTextReg_st);
        st_degree = (EditText) findViewById(R.id.editTextDegree_st);
        st_department = (EditText) findViewById(R.id.editTextDepartment_st);
        st_phone = (EditText) findViewById(R.id.editTextPhone_st);
        st_email = (EditText) findViewById(R.id.editTextEmail_st);


    }

    public void ViewData_Method(View view) {
        Intent firstIntent = new Intent(getApplicationContext(), StudentList.class);
        //firstIntent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
        startActivity(firstIntent);

    }

    public void SaveData_Method(View view) {
        try{

            // Opens a current database or creates it
            // Pass the database name, designate that only this app can use it
            // and a DatabaseErrorHandler in the case of database corruption
            contactsDB = this.openOrCreateDatabase("MyDatabase2101", MODE_PRIVATE, null);

            // Execute an SQL statement that isn't select
            contactsDB.execSQL("CREATE TABLE IF NOT EXISTS student_detail " +
                    "(id integer primary key not null," +
                    " student_name VARCHAR," +
                    " student_reg VARCHAR," +
                    " student_degree VARCHAR," +
                    " student_department VARCHAR," +
                    " student_email VARCHAR," +
                    " student_phone VARCHAR);");
            //Toast.makeText(getApplicationContext(), "Database Created", Toast.LENGTH_SHORT).show();

            // The database on the file system
            File database = getApplicationContext().getDatabasePath("MyDatabase2101.db");

            // Check if the database exists
            if (database.exists()) {
                Toast.makeText(getApplicationContext(), "Database Created", Toast.LENGTH_SHORT).show();
            } else {
                //Toast.makeText(getApplicationContext(), "Database Missing", Toast.LENGTH_SHORT).show();
            }

        }

        catch(Exception e){

            Log.e("CONTACTS ERROR", "Error Creating Database" + e);
            Toast.makeText(getApplicationContext(), "Error Creating Database", Toast.LENGTH_SHORT).show();

        }

        String name = st_name.getText().toString();
        String reg = st_reg.getText().toString();
        String degree = st_degree.getText().toString();
        String dep = st_department.getText().toString();
        String phone = st_phone.getText().toString();
        String email = st_email.getText().toString();

        try {
            contactsDB.execSQL("INSERT INTO student_detail (student_name,student_reg,student_degree,student_department," +
                    "student_phone, student_email)" +
                    " VALUES ('" + name + "', '" + reg + "','" + degree + "','" + dep
                    + "','" + phone + "','" + email + "');");

            Toast.makeText(getApplicationContext(), "Data Added", Toast.LENGTH_SHORT).show();


        }
        catch(Exception f)
        {
            Log.e("CONTACTS ERROR", "Error Inserting Data" + f);

        }

    }
}
