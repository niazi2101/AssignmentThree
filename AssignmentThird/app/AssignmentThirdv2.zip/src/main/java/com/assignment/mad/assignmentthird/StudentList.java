package com.assignment.mad.assignmentthird;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.widget.ListView;
import android.widget.SimpleCursorAdapter;
import android.widget.Toast;

import java.util.List;

public class StudentList extends AppCompatActivity {


    SQLiteDatabase contactsDB = null;

    Cursor cursor;
    String[] columns;

    ListView listView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_student_list);


        try {

            // Opens a current database or creates it
            // Pass the database name, designate that only this app can use it
            // and a DatabaseErrorHandler in the case of database corruption
            contactsDB = this.openOrCreateDatabase("MyDatabase2101", MODE_PRIVATE, null);

            // Execute an SQL statement that isn't select

        } catch (Exception e) {

            Log.e("DATABASE ERROR", "Error Creating Database" + e);
            Toast.makeText(getApplicationContext(), "Error Creating Database", Toast.LENGTH_SHORT).show();

        }

        try {
            cursor = contactsDB.rawQuery("SELECT student_name,student_reg,student_degree" +
                    " FROM student_detail", null);

            // Get the index for the column name provided
            int nameColumn = cursor.getColumnIndex("student_name");
            int regColumn = cursor.getColumnIndex("student_reg");
            int degreeColumn = cursor.getColumnIndex("student_degree");


            // Move to the first row of results
            cursor.moveToFirst();


            // Verify that we have results
            if (cursor != null && (cursor.getCount() > 0)) {

                do {
                    // Get the results and store them in a String
                    //      String DBid = cursor.getString(idColumn);
                    String DBname = cursor.getString(nameColumn);
                    String DBreg = cursor.getString(regColumn);
                    String DBdegree = cursor.getString(degreeColumn);



                    // Keep getting results as long as they exist
                } while (cursor.moveToNext());

               // String ColumnName = nameColumn.
                columns = new String[] {
                        "student_name",
                        "student_reg",
                        "student_degree"


                };
                //contactListEditText.setText(contactList);

            } else {

                Toast.makeText(getApplicationContext(), "No Results to Show", Toast.LENGTH_SHORT).show();
                //contactListEditText.setText("");

            }
        }catch(Exception e)
        {
            Log.e("Cursor","Problem with cursor in Student list" + e);
        }

        int [] widgets = new int[] {
                R.id.studentReg,
                R.id.studentName,
                R.id.studentDegree
        };

        SimpleCursorAdapter cursorAdapter = new SimpleCursorAdapter(this, R.layout.list_item,
                cursor, columns, widgets, 0);
        listView = (ListView)findViewById(R.id.listView);

        listView.setAdapter(cursorAdapter);


    }
}
