package com.assignment.mad.assignmentthird;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.database.DatabaseUtils;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.SimpleCursorAdapter;
import android.widget.Toast;

import java.util.List;

public class StudentList extends AppCompatActivity {

    DBhandler handler;
    Cursor cursor;
    String[] columns;

    TodoCursorAdaptor todoAdaptor;
    ListView listView;

    Context context = this;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_student_list);

        try {
            handler = new DBhandler(this);

            cursor = handler.getAllStudents();
            Log.v("Cursor Object", DatabaseUtils.dumpCursorToString(cursor));
            /*String[] columns = new String[]{
                    handler.STUDENT_COLUMN_ID,
                    handler.STUDENT_COLUMN_NAME


            };*/
        /*int[] widgets = new int[]{
                R.id.studentReg,
                R.id.studentName
        };*/

        /*SimpleCursorAdapter cursorAdapter = new SimpleCursorAdapter(this, R.layout.list_item,
                cursor, columns, widgets, 0);*/
            listView = (ListView) findViewById(R.id.listView);

            todoAdaptor = new TodoCursorAdaptor(context, cursor, 0);
            listView.setAdapter(todoAdaptor);

            listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {

                @Override
                public void onItemClick(AdapterView listView, View view,
                                        int position, long id) {
                /*Cursor itemCursor = (Cursor) MainActivity.this.listView.getItemAtPosition(position);
                int personID = itemCursor.getInt(itemCursor.getColumnIndex(ExampleDBHelper.PERSON_COLUMN_ID));
                */
                    // Show The Dialog with Selected SMS
                    AlertDialog dialog = new AlertDialog.Builder(getApplicationContext()).create();
                    dialog.setTitle("Item Clicked");
                    dialog.setIcon(android.R.drawable.ic_dialog_info);
                    dialog.setMessage("You have clicked a list item");
                    dialog.setButton(DialogInterface.BUTTON_POSITIVE, "OK",
                            new DialogInterface.OnClickListener() {
                                public void onClick(DialogInterface dialog, int which) {

                                    dialog.dismiss();
                                    return;
                                }
                            });
                    dialog.show();


                }
            });
        }catch(Exception e)
        {
            Log.e("ERROR","UNABLE TO DISPLAY STUDENT LIST: "+e);
            Log.e("ERROR","UNABLE TO DISPLAY STUDENT LIST: "+cursor.getColumnNames().toString());
        }

    }

}
